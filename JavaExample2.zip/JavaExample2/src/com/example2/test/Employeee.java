package com.example2.test;

public interface Employeee {
	

}
