package com.example2.test;

//Interface
interface offficeAdress {
	
	void draw(); // Abstract method
}

//Class implementing the interface
class Employuee1 implements offficeAdress {
	@Override
	public void draw() {
		System.out.println("Drawing a rectangle");
	}
}

class Employee2 implements offficeAdress {

	@Override
	public void draw() {
		
	}
	
}

public class Main7 {
	public static void main(String[] args) {
		offficeAdress myDrawable = new Employuee1();
		myDrawable.draw(); // Calls the method implemented in Rectangle
	}
}
