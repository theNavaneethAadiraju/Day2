package com.example2.test;

class Calculator {
	// Method for integer addition
	int add(int a, int b) {
		return a + b;
	}

	// Method for double addition
	double add(double a, double b) {
		return a + b;
	}
}

public class Main3 {
	public static void main(String[] args) {
		Calculator calc = new Calculator();
		System.out.println(calc.add(10, 20)); // Calls integer version
		System.out.println(calc.add(10.5, 20.5)); // Calls double version
		
	}
}
