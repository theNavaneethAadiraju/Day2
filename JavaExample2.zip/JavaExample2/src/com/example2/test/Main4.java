package com.example2.test;

class Animall {
	void sound() {
		System.out.println("Animal makes a sound");
	}
}

class Cat extends Animall {
	@Override
	void sound() {
		System.out.println("Cat meows");
	}
}

public class Main4 {
	public static void main(String[] args) {
		Animall myCat = new Cat();
		myCat.sound(); // Calls overridden method in Cat
	}
}
