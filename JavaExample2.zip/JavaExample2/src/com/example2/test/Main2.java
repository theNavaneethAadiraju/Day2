package com.example2.test;
//Inheritance
//Superclass
class Animal {
	void eat() {
//		int j=12;
//		int i =10;
		System.out.println("Eating");
	}
}

//Subclass
class Dog extends Animal {
	void bark() {
		int i=11;
	//	System.out.println(j);
		System.out.println("barking");
	}
}

public class Main2 {
	public static void main(String[] args) {
		
		Dog a = new Dog();
		a.bark();
		a.eat();
	//	((Dog) a).bark();
		
	//	a.eat(); // Inherited method
	//	myDog.bark(); // Subclass method
	}
}
