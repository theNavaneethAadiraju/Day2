package com.example2.test;

//Abstract class
abstract class Shape {
	abstract void draw(); // Abstract method
}

//Concrete subclass
class Circle extends Shape {
	@Override
	void draw() {
		System.out.println("Drawing a circle");
	}
}

public class Main6 {
	public static void main(String[] args) {
		Shape myShape = new Circle();
		myShape.draw(); // Calls the overridden method in Circle
	}
}
