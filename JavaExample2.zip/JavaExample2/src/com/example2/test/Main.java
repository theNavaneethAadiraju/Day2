package com.example2.test;
//class and object
//Define a class named 'Car'
class Car {
	// Fields (Attributes)
	String color;
	String model;

	// Method to display car details
	void displayDetails() {
		System.out.println("Model: " + model);
		System.out.println("Color: " + color);
	}
}

public class Main {
	public static void main(String[] args) {
		// Create an object of the 'Car' class
		Car myCar = new Car();
		myCar.color = "Red";
		myCar.model = "Toyota Corolla";

		// Call the method on the object
		myCar.displayDetails();
	}
}
